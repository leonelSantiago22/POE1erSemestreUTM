#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <iostream>
#include <ostream>

using namespace std;

int main()
{
    int ahorro=3, i=1;

    while (i<=365)
    {
        ahorro*=3;
        printf(" ahorro total %d: ");
        i++
    }

    getchar() getchar ();